//
//  AppDelegate.swift
//  Cursor Hijacker
//
//  Created by Miles Checkley on 17/05/2026.
//

import Cocoa

@main
class AppDelegate: NSObject, NSApplicationDelegate {

    func applicationDidFinishLaunching(_ aNotification: Notification) {
        lockCursor()
        Timer.scheduledTimer(withTimeInterval: 0.001, repeats: true) { _ in
            self.snapCursorToWindowCentre()
        }
        Timer.scheduledTimer(withTimeInterval: 0.5, repeats: true) { _ in
            self.moveWindowToRandomEdge()
        }
        
    }

    func applicationWillTerminate(_ aNotification: Notification) {
        unlockCursor()
    }

    func applicationSupportsSecureRestorableState(_ app: NSApplication) -> Bool {
        return true
    }

    func lockCursor() {
        CGDisplayHideCursor(CGMainDisplayID())
        CGAssociateMouseAndMouseCursorPosition(0)
    }

    func unlockCursor() {
        CGAssociateMouseAndMouseCursorPosition(1)
        CGDisplayShowCursor(CGMainDisplayID())
    }

    func snapCursorToWindowCentre() {
        NSCursor.unhide()
        guard let window = NSApplication.shared.windows.first else { return }
        let centre = CGPoint(
            x: window.frame.midX,
            y: CGFloat(CGDisplayPixelsHigh(CGMainDisplayID())) - window.frame.midY
        )
        CGWarpMouseCursorPosition(centre)
    }
    
    func moveWindowToRandomEdge() {
        guard let window = NSApplication.shared.windows.first,
                  let screen = NSScreen.main else { return }

        let screenFrame = screen.visibleFrame
        let windowSize = window.frame.size
        let edge = Int.random(in: 0...3)
        var newFrame = window.frame

        switch edge {
        case 0:
            newFrame.origin.x = screenFrame.minX
            newFrame.origin.y = CGFloat.random(in: screenFrame.minY...(screenFrame.maxY - windowSize.height))
        case 1:
            newFrame.origin.x = screenFrame.maxX - windowSize.width
            newFrame.origin.y = CGFloat.random(in: screenFrame.minY...(screenFrame.maxY - windowSize.height))
        case 2:
            newFrame.origin.y = screenFrame.maxY - windowSize.height
            newFrame.origin.x = CGFloat.random(in: screenFrame.minX...(screenFrame.maxX - windowSize.width))
        case 3:
            newFrame.origin.y = screenFrame.minY
            newFrame.origin.x = CGFloat.random(in: screenFrame.minX...(screenFrame.maxX - windowSize.width))
        default:
            break
        }

        NSAnimationContext.runAnimationGroup { context in
            context.duration = 0.5
            context.timingFunction = CAMediaTimingFunction(name: .easeInEaseOut)
            window.animator().setFrame(newFrame, display: true)
        }
    }

}
