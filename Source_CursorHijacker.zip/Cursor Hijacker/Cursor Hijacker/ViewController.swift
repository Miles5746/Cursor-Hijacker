//
//  ViewController.swift
//  Cursor Hijacker
//
//  Created by Miles Checkley on 17/05/2026.
//

import Cocoa

class ViewController: NSViewController {

    override func viewDidAppear() {
        super.viewDidAppear()
        guard let window = view.window else { return }
        
        window.isOpaque = false
        window.backgroundColor = .clear
        window.titlebarAppearsTransparent = true
        window.titleVisibility = .hidden
        window.styleMask.insert(.fullSizeContentView)
        window.standardWindowButton(.closeButton)?.isHidden = true
        window.standardWindowButton(.miniaturizeButton)?.isHidden = true
        window.standardWindowButton(.zoomButton)?.isHidden = true
    }

    override var representedObject: Any? {
        didSet {
        // Update the view, if already loaded.
        }
    }

}

